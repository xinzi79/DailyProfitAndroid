package com.example.dailyprofit;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.text.InputType;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int BLUE = Color.rgb(35, 105, 230), GREEN = Color.rgb(25, 150, 90), RED = Color.rgb(220, 70, 70);
    DB db; LinearLayout root, content; String tab = "today";
    String[] incomeCats = {"工资","经营收入","兼职","奖金","其他收入"};
    String[] expenseCats = {"餐饮","交通","购物","住房","娱乐","生活缴费","进货成本","其他支出"};
    @Override public void onCreate(Bundle b) { super.onCreate(b); db = new DB(this); show(); }
    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    TextView text(String s, int size, int color) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setGravity(Gravity.CENTER_VERTICAL); return v;
    }
    LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(16),dp(8),dp(16),dp(12)); return l; }
    LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void add(LinearLayout parent, View v, int h) { parent.addView(v, new LinearLayout.LayoutParams(-1,h < 0 ? h : dp(h))); }
    Button button(String s, Runnable r) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(v -> r.run()); return b; }
    String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(new Date()); }
    String month() { return new SimpleDateFormat("yyyy-MM", Locale.CHINA).format(new Date()); }
    void show() {
        root = column(); root.setPadding(dp(16),dp(12),dp(16),dp(8));
        root.setBackgroundColor(Color.rgb(247,249,252));
        TextView title = text("每日收支利润", 24, Color.rgb(25,35,55)); title.setTypeface(null,1); add(root,title,42);
        TextView sub = text("记清每一笔，自动算出每天赚多少",13,Color.GRAY); add(root,sub,28);
        LinearLayout nav = row();
        nav.addView(button("今日", ()->{tab="today";show();}),new LinearLayout.LayoutParams(0,dp(48),1));
        nav.addView(button("历史记录", ()->{tab="history";show();}),new LinearLayout.LayoutParams(0,dp(48),1));
        nav.addView(button("月度统计", ()->{tab="month";show();}),new LinearLayout.LayoutParams(0,dp(48),1));
        add(root,nav,50);
        ScrollView scroll = new ScrollView(this); content = column(); content.setPadding(0,dp(8),0,dp(20)); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        if(tab.equals("today")) todayPage(); else if(tab.equals("history")) historyPage(); else monthPage();
    }
    void summary(String label, double income, double expense) {
        LinearLayout card = column(); card.setBackgroundColor(Color.WHITE); card.setPadding(dp(16),dp(12),dp(16),dp(12));
        TextView lab=text(label,14,Color.GRAY); add(card,lab,26);
        TextView profit=text(String.format(Locale.CHINA,"¥ %.2f",income-expense),30,income-expense>=0?GREEN:RED); profit.setTypeface(null,1); add(card,profit,46);
        LinearLayout stats=row();
        TextView inc=text(String.format(Locale.CHINA,"收入  ¥ %.2f",income),15,GREEN);
        TextView exp=text(String.format(Locale.CHINA,"支出  ¥ %.2f",expense),15,RED);
        stats.addView(inc,new LinearLayout.LayoutParams(0,dp(34),1)); stats.addView(exp,new LinearLayout.LayoutParams(0,dp(34),1)); add(card,stats,36);
        add(content,card,-2); space(8);
    }
    void space(int h) { View v=new View(this); add(content,v,h); }
    double[] totals(String where, String arg) {
        double in=0,out=0; Cursor c=db.getReadableDatabase().rawQuery("SELECT type,SUM(amount) FROM records "+where+" GROUP BY type",(where.contains("?") && arg!=null)?new String[]{arg}:null);
        while(c.moveToNext()){ if(c.getString(0).equals("收入")) in=c.getDouble(1); else out=c.getDouble(1); } c.close(); return new double[]{in,out};
    }
    void todayPage() {
        double[] t=totals("WHERE date=?",today()); summary("今天 · "+today(),t[0],t[1]);
        add(content,button("＋ 记一笔收入",()->entry("收入")),54);
        add(content,button("－ 记一笔支出",()->entry("支出")),54);
        space(8); add(content,text("今日明细",18,Color.DKGRAY),34); list("WHERE date=?",today());
    }
    void entry(String type) {
        LinearLayout box=column();
        EditText amount=new EditText(this); amount.setSingleLine(true); amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); amount.setHint("金额（必填）"); box.addView(amount);
        String[] cats=type.equals("收入")?incomeCats:expenseCats;
        Spinner category=new Spinner(this); category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats)); box.addView(category);
        EditText note=new EditText(this); note.setSingleLine(true); note.setHint("备注（选填）"); box.addView(note);
        new AlertDialog.Builder(this).setTitle("添加"+type).setView(box)
          .setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{
              try { double a=Double.parseDouble(amount.getText().toString().trim()); if(a<=0) throw new Exception();
                  ContentValues cv=new ContentValues(); cv.put("type",type); cv.put("amount",a); cv.put("category",cats[category.getSelectedItemPosition()]);
                  cv.put("note",note.getText().toString().trim()); cv.put("date",today()); cv.put("created",System.currentTimeMillis());
                  db.getWritableDatabase().insert("records",null,cv); show();
              } catch(Exception e) { Toast.makeText(this,"请输入大于 0 的有效金额",Toast.LENGTH_SHORT).show(); }
          }).show();
    }
    void historyPage() {
        add(content,text("历史记录",20,Color.DKGRAY),40);
        add(content,button("选择日期查看",()->{
            Calendar c=Calendar.getInstance();
            new DatePickerDialog(this,(v,y,m,d)->{String date=String.format(Locale.CHINA,"%04d-%02d-%02d",y,m+1,d); tab="history"; showHistoryDate(date);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
        }),48);
        double[] t=totals("",null); summary("全部记录汇总",t[0],t[1]); list("",null); 
    }
    void showHistoryDate(String date) {
        root.removeViewAt(root.getChildCount()-1); ScrollView sc=new ScrollView(this); content=column(); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        double[] t=totals("WHERE date=?",date); summary(date,t[0],t[1]); add(content,text("当日明细",18,Color.DKGRAY),36); list("WHERE date=?",date);
    }
    void monthPage() {
        String m=month(); double[] t=totals("WHERE date LIKE ?",m+"%");
        summary(m+" 月度汇总",t[0],t[1]);
        add(content,button("选择月份",()->{
            Calendar c=Calendar.getInstance();
            new DatePickerDialog(this,(v,y,mo,d)->{String chosen=String.format(Locale.CHINA,"%04d-%02d",y,mo+1); showMonth(chosen);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),1).show();
        }),48);
        add(content,text("本月分类支出",18,Color.DKGRAY),38);
        Cursor c=db.getReadableDatabase().rawQuery("SELECT category,SUM(amount) FROM records WHERE type='支出' AND date LIKE ? GROUP BY category ORDER BY SUM(amount) DESC",new String[]{m+"%"});
        while(c.moveToNext()) add(content,text("• "+c.getString(0)+"     ¥ "+String.format(Locale.CHINA,"%.2f",c.getDouble(1)),15,Color.DKGRAY),34); c.close();
        add(content,text("本月每日利润",18,Color.DKGRAY),38);
        Cursor days=db.getReadableDatabase().rawQuery("SELECT date, SUM(CASE WHEN type='收入' THEN amount ELSE -amount END) FROM records WHERE date LIKE ? GROUP BY date ORDER BY date DESC",new String[]{m+"%"});
        while(days.moveToNext()) add(content,text(days.getString(0)+"     ¥ "+String.format(Locale.CHINA,"%.2f",days.getDouble(1)),14,days.getDouble(1)>=0?GREEN:RED),32); days.close();
    }
    void showMonth(String m) {
        root.removeViewAt(root.getChildCount()-1); ScrollView sc=new ScrollView(this); content=column(); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        double[] t=totals("WHERE date LIKE ?",m+"%"); summary(m+" 月度汇总",t[0],t[1]);
        Cursor c=db.getReadableDatabase().rawQuery("SELECT category,SUM(amount) FROM records WHERE type='支出' AND date LIKE ? GROUP BY category ORDER BY SUM(amount) DESC",new String[]{m+"%"});
        add(content,text("分类支出",18,Color.DKGRAY),38); while(c.moveToNext()) add(content,text(c.getString(0)+"   ¥ "+String.format(Locale.CHINA,"%.2f",c.getDouble(1)),15,Color.DKGRAY),32); c.close();
        Cursor days=db.getReadableDatabase().rawQuery("SELECT date, SUM(CASE WHEN type='收入' THEN amount ELSE -amount END) FROM records WHERE date LIKE ? GROUP BY date ORDER BY date DESC",new String[]{m+"%"});
        add(content,text("每日利润",18,Color.DKGRAY),38); while(days.moveToNext()) add(content,text(days.getString(0)+"   ¥ "+String.format(Locale.CHINA,"%.2f",days.getDouble(1)),14,Color.DKGRAY),32); days.close();
    }
    void list(String where,String arg) {
        String sql="SELECT id,type,amount,category,note,date FROM records "+where+" ORDER BY date DESC, id DESC";
        Cursor c=db.getReadableDatabase().rawQuery(sql,arg==null?null:new String[]{arg});
        if(c.getCount()==0){ add(content,text("暂无记录，点击上方按钮记第一笔账。",14,Color.GRAY),44); }
        while(c.moveToNext()){
            long id=c.getLong(0); String type=c.getString(1); double amount=c.getDouble(2);
            String line=(type.equals("收入")?"+ ":"− ")+"¥ "+String.format(Locale.CHINA,"%.2f",amount)+"  ·  "+c.getString(3);
            String note=c.getString(4); if(note!=null&&!note.isEmpty()) line+="\n"+note;
            if(where.isEmpty()) line+="\n"+c.getString(5);
            TextView tv=text(line,15,type.equals("收入")?GREEN:RED); tv.setPadding(dp(8),dp(6),dp(8),dp(6));
            tv.setBackgroundColor(Color.WHITE); add(content,tv, note!=null&&!note.isEmpty()?62:48);
            tv.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("删除这条记录？").setNegativeButton("取消",null).setPositiveButton("删除",(a,b)->{db.getWritableDatabase().delete("records","id=?",new String[]{String.valueOf(id)});show();}).show();return true;});
        } c.close();
    }
    static class DB extends SQLiteOpenHelper {
        DB(android.content.Context context){super(context,"daily_profit.db",null,1);}
        @Override public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE records(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,amount REAL NOT NULL,category TEXT NOT NULL,note TEXT,date TEXT NOT NULL,created INTEGER NOT NULL)");}
        @Override public void onUpgrade(SQLiteDatabase d,int o,int n){}
    }
}