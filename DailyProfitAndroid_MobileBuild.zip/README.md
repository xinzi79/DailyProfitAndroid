# 每日收支利润（Android）

中文本地记账应用，包含：
- 每日收入、支出与自动利润计算
- 收入/支出分类和备注
- 历史记录、按日期筛选、长按删除
- 月度汇总、分类支出与每日利润
- SQLite 本地保存，无需注册账号或联网

## 构建 APK
1. 用 Android Studio 打开此项目文件夹。
2. 让 Android Studio 安装所需的 Android SDK（compileSdk 35）和 Gradle 插件。
3. 在 `app/src/main/java/com/example/dailyprofit/MainActivity.java` 中，需在创建 DB 前传入 Activity Context（见下方修正说明）。
4. 选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
5. APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 注意
当前执行环境没有 Android SDK/Gradle，无法在这里实际编译或验证 APK。因此本交付为 Android Studio 项目源码，不是已编译 APK。


## 仅用安卓手机在线构建（GitHub Actions）
此项目包含 `.github/workflows/build-apk.yml`，可让 GitHub 云端编译 APK：
1. 在手机浏览器打开 https://github.com 并登录/注册账号。
2. 创建一个新仓库，名字可填 `DailyProfitAndroid`，选择 Public 或 Private 均可。
3. 在仓库页面选择 **Add file → Upload files**，上传本 ZIP 解压后的所有项目文件和文件夹（包括隐藏的 `.github` 文件夹；若手机文件选择器隐藏点号文件，先用文件管理器显示隐藏文件，或按下面说明使用网页创建 workflow）。
4. 上传完成后打开仓库的 **Actions** 标签，允许 Actions 运行；若 workflow 没有自动启动，进入 **Build Android APK**，点击 **Run workflow**。
5. 等待任务完成，点开成功的运行记录，在 **Artifacts** 中下载 `DailyProfit-debug-apk`，解压得到 `app-debug.apk`。
6. 在手机“文件管理”中打开 APK 安装。如果系统提示，允许浏览器/文件管理器“安装未知应用”。

注意：GitHub 的页面布局可能随版本变化；上传整个项目时需确保 `.github/workflows/build-apk.yml` 被上传。不要把账号密码发给任何人。
